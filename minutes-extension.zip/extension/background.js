// Service worker -- the extension's coordinator. Holds recording state so
// that closing/reopening the popup (which Chrome does automatically) never
// loses track of what's happening, since the popup itself gets destroyed
// each time it loses focus.

const API_BASE_URL = "http://localhost:8000";

let currentState = { status: "idle" }; // idle | recording | uploading | processing | done | failed
let offscreenCreating = null;

async function ensureOffscreenDocument() {
  const existingContexts = await chrome.runtime.getContexts({
    contextTypes: ["OFFSCREEN_DOCUMENT"],
  });
  if (existingContexts.length > 0) return;

  if (offscreenCreating) {
    await offscreenCreating;
    return;
  }
  offscreenCreating = chrome.offscreen.createDocument({
    url: "offscreen.html",
    reasons: ["USER_MEDIA"],
    justification: "Recording tab audio for meeting transcription",
  });
  await offscreenCreating;
  offscreenCreating = null;
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.target === "background") {
    if (message.type === "start-recording") {
      handleStartRecording(sendResponse);
      return true; // keep the message channel open for the async response
    }
    if (message.type === "stop-recording") {
      currentState = { status: "uploading" };
      chrome.runtime.sendMessage({ target: "offscreen", type: "stop-recording" });
    }
    if (message.type === "get-status") {
      sendResponse(currentState);
    }
  }

  // Status updates relayed from the offscreen document
  if (message.target === "background-status") {
    currentState = message.state;
    // Best-effort forward to the popup if it's currently open and listening
    chrome.runtime.sendMessage({ target: "popup", state: currentState }).catch(() => {});
  }
});

async function handleStartRecording(sendResponse) {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) throw new Error("No active tab found.");

    const streamId = await chrome.tabCapture.getMediaStreamId({ targetTabId: tab.id });
    await ensureOffscreenDocument();

    chrome.runtime.sendMessage({
      target: "offscreen",
      type: "start-recording",
      streamId,
      tabTitle: tab.title || "recording",
      apiBaseUrl: API_BASE_URL,
    });

    currentState = { status: "recording" };
    sendResponse({ ok: true });
  } catch (err) {
    currentState = { status: "idle" };
    sendResponse({ ok: false, error: err.message });
  }
}
